button text: SQL is Off
primary color: 666666
gradient color: 333333
width (pixels): 80
height (pixels): 18
corner radius (pixels): 8
text height (points): 8
text color: ffffff
background color: white
font name: Helmet bold
rollover primary color: aaaaaa
rollover gradient color: bbbbbb
rollover text color: 000000
quality: 3
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/buttonmill/glassy.php?button_text=SQL+is+Off&color=666666&grcolor=333333&width=80&height=18&radius=8&theight=8&tcolor=ffffff&bkcolor=white&fname=Helmet+bold&rcolor=aaaaaa&rgrcolor=bbbbbb&rtcolor=000000&imglocate=none&imgheight=12&imgname=&imgfore=auto&imgforecolor=000000&imgtran=auto&imgtrancolor=ffffff&quality=3&fromhere=1
