button text: Refresh
primary color: 3366ff
gradient color: 330099
width (pixels): 80
height (pixels): 18
corner radius (pixels): 8
text height (points): 8
text color: ffffff
background color: white
font name: Helmet bold
rollover primary color: 66ffff
rollover gradient color: 6666ff
rollover text color: 000000
quality: 4
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/buttonmill/glassy.php?button_text=Refresh&color=3366ff&grcolor=330099&width=80&height=18&radius=8&theight=8&tcolor=ffffff&bkcolor=white&fname=Helmet+bold&rcolor=66ffff&rgrcolor=6666ff&rtcolor=000000&imglocate=none&imgheight=12&imgname=&imgfore=auto&imgforecolor=000000&imgtran=auto&imgtrancolor=ffffff&quality=4&fromhere=1
